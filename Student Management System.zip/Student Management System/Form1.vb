﻿' ==============================
' Student Management System
' ==============================
Imports MySql.Data.MySqlClient
Imports iText.Kernel.Pdf
Imports iText.Layout
Imports iText.Layout.Element
Imports System.IO
Imports System.Diagnostics
Imports iText.Layout.Properties

Public Class Form1
    ' Connection string — update password if needed
    Private connString As String = "server=localhost;user=root;password=;database=studentdb;"

    ' Track currently selected student ID
    Private currentID As Integer = -1

    ' Form load: style title and load data
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblTitle.Font = New Font(lblTitle.Font, FontStyle.Bold)
        lblTitle.TextAlign = ContentAlignment.MiddleCenter

        LoadStudents()
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    ' Load all students from MySQL into DataGridView
    Private Sub LoadStudents()
        Try
            Using conn As New MySqlConnection(connString)
                conn.Open()
                Dim query As String = "SELECT id, name, age, course, email FROM students ORDER BY id"
                Using cmd As New MySqlCommand(query, conn)
                    Dim adapter As New MySqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    dgvStudents.DataSource = table
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading students: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Validate user input
    Private Function ValidateInput() As Boolean
        If String.IsNullOrWhiteSpace(txtName.Text) Then
            MessageBox.Show("Name is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtAge.Text) OrElse Not IsNumeric(txtAge.Text) OrElse CInt(txtAge.Text) <= 0 Then
            MessageBox.Show("Valid age (positive number) is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtCourse.Text) Then
            MessageBox.Show("Course is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtEmail.Text) OrElse Not txtEmail.Text.Contains("@") Then
            MessageBox.Show("Valid email is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return False
        End If

        Return True
    End Function

    ' Add new student
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If Not ValidateInput() Then Return

        Try
            Using conn As New MySqlConnection(connString)
                conn.Open()
                Dim query As String = "INSERT INTO students (name, age, course, email) VALUES (@name, @age, @course, @email)"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim())
                    cmd.Parameters.AddWithValue("@age", CInt(txtAge.Text))
                    cmd.Parameters.AddWithValue("@course", txtCourse.Text.Trim())
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Student added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearFields()
            LoadStudents()
        Catch ex As Exception
            MessageBox.Show("Error adding student: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Update existing student
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If currentID = -1 Then
            MessageBox.Show("Please select a student first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        If Not ValidateInput() Then Return

        Try
            Using conn As New MySqlConnection(connString)
                conn.Open()
                Dim query As String = "UPDATE students SET name=@name, age=@age, course=@course, email=@email WHERE id=@id"
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@id", currentID)
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim())
                    cmd.Parameters.AddWithValue("@age", CInt(txtAge.Text))
                    cmd.Parameters.AddWithValue("@course", txtCourse.Text.Trim())
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Student updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ClearFields()
            LoadStudents()
        Catch ex As Exception
            MessageBox.Show("Error updating student: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Delete selected student
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If currentID = -1 Then
            MessageBox.Show("Please select a student to delete.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        If MessageBox.Show("Are you sure you want to delete this student?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Try
                Using conn As New MySqlConnection(connString)
                    conn.Open()
                    Dim query As String = "DELETE FROM students WHERE id = @id"
                    Using cmd As New MySqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@id", currentID)
                        cmd.ExecuteNonQuery()
                    End Using
                End Using

                MessageBox.Show("Student deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ClearFields()
                LoadStudents()
            Catch ex As Exception
                MessageBox.Show("Error deleting student: " & ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    ' Clear all input fields
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub

    ' Reset form state
    Private Sub ClearFields()
        txtName.Clear()
        txtAge.Clear()
        txtCourse.Clear()
        txtEmail.Clear()
        currentID = -1
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    ' Handle DataGridView row selection
    Private Sub dgvStudents_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvStudents.CellClick
        If e.RowIndex >= 0 AndAlso e.RowIndex < dgvStudents.Rows.Count - 1 Then
            Dim row As DataGridViewRow = dgvStudents.Rows(e.RowIndex)
            currentID = CInt(If(row.Cells("id").Value Is Nothing, 0, row.Cells("id").Value))
            txtName.Text = If(row.Cells("name").Value Is Nothing, "", row.Cells("name").Value.ToString())
            txtAge.Text = If(row.Cells("age").Value Is Nothing, "", row.Cells("age").Value.ToString())
            txtCourse.Text = If(row.Cells("course").Value Is Nothing, "", row.Cells("course").Value.ToString())
            txtEmail.Text = If(row.Cells("email").Value Is Nothing, "", row.Cells("email").Value.ToString())

            btnUpdate.Enabled = True
            btnDelete.Enabled = True
        End If
    End Sub

    ' Generate PDF Report
    Private Sub btnGeneratePDF_Click(sender As Object, e As EventArgs) Handles btnGeneratePDF.Click
        Dim pdfPath As String = Path.Combine(Application.StartupPath, "StudentReport.pdf")
        Try
            Using writer As New PdfWriter(pdfPath)
                Using pdfDoc As New PdfDocument(writer)
                    Dim doc As New Document(pdfDoc)

                    ' Title
                    doc.Add(New Paragraph("Student Management System - Report") _
                        .SetTextAlignment(iText.Layout.Properties.TextAlignment.CENTER) _
                        .SetFontSize(18))

                    doc.Add(New Paragraph(" ").SetMarginTop(10))

                    ' Create table
                    Dim table As New Table(5)
                    table.SetWidth(UnitValue.CreatePercentValue(100))

                    ' Headers
                    Dim headers As String() = {"ID", "Name", "Age", "Course", "Email"}
                    For Each header In headers
                        table.AddCell(header)
                    Next

                    ' Data rows
                    For Each row As DataGridViewRow In dgvStudents.Rows
                        If Not row.IsNewRow Then
                            Dim id = If(row.Cells("id").Value Is Nothing, "", row.Cells("id").Value.ToString())
                            Dim name = If(row.Cells("name").Value Is Nothing, "", row.Cells("name").Value.ToString())
                            Dim age = If(row.Cells("age").Value Is Nothing, "", row.Cells("age").Value.ToString())
                            Dim course = If(row.Cells("course").Value Is Nothing, "", row.Cells("course").Value.ToString())
                            Dim email = If(row.Cells("email").Value Is Nothing, "", row.Cells("email").Value.ToString())

                            table.AddCell(id)
                            table.AddCell(name)
                            table.AddCell(age)
                            table.AddCell(course)
                            table.AddCell(email)
                        End If
                    Next

                    doc.Add(table)
                    doc.Add(New Paragraph(" ").SetMarginTop(20))
                    doc.Add(New Paragraph("Note: Application screenshots should be included separately in your project documentation."))

                    doc.Close()
                End Using
            End Using

            MessageBox.Show($"PDF report saved to:{vbCrLf}{pdfPath}", "PDF Generated", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Process.Start(New ProcessStartInfo(pdfPath) With {.UseShellExecute = True})

        Catch ex As Exception
            MessageBox.Show("Failed to generate PDF: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class