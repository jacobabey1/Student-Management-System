﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblTitle = New Label()
        Label1 = New Label()
        txtName = New TextBox()
        Label2 = New Label()
        txtAge = New TextBox()
        Label3 = New Label()
        txtCourse = New TextBox()
        Label4 = New Label()
        txtEmail = New TextBox()
        btnAdd = New Button()
        btnClear = New Button()
        btnDelete = New Button()
        btnGeneratePDF = New Button()
        btnUpdate = New Button()
        dgvStudents = New DataGridView()
        Label5 = New Label()
        CType(dgvStudents, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(263, 9)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(235, 21)
        lblTitle.TabIndex = 0
        lblTitle.Text = "Student Management System"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(50, 71)
        Label1.Name = "Label1"
        Label1.Size = New Size(56, 21)
        Label1.TabIndex = 1
        Label1.Text = "Name"
        ' 
        ' txtName
        ' 
        txtName.Location = New Point(169, 69)
        txtName.Name = "txtName"
        txtName.Size = New Size(144, 23)
        txtName.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(66, 147)
        Label2.Name = "Label2"
        Label2.Size = New Size(40, 21)
        Label2.TabIndex = 3
        Label2.Text = "Age"
        ' 
        ' txtAge
        ' 
        txtAge.Location = New Point(169, 145)
        txtAge.Name = "txtAge"
        txtAge.Size = New Size(144, 23)
        txtAge.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(50, 212)
        Label3.Name = "Label3"
        Label3.Size = New Size(62, 21)
        Label3.TabIndex = 5
        Label3.Text = "Course"
        ' 
        ' txtCourse
        ' 
        txtCourse.Location = New Point(169, 214)
        txtCourse.Name = "txtCourse"
        txtCourse.Size = New Size(144, 23)
        txtCourse.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(59, 283)
        Label4.Name = "Label4"
        Label4.Size = New Size(53, 21)
        Label4.TabIndex = 7
        Label4.Text = "Email"
        ' 
        ' txtEmail
        ' 
        txtEmail.Location = New Point(169, 281)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(144, 23)
        txtEmail.TabIndex = 8
        ' 
        ' btnAdd
        ' 
        btnAdd.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAdd.ForeColor = Color.Black
        btnAdd.Location = New Point(50, 328)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(141, 35)
        btnAdd.TabIndex = 9
        btnAdd.Text = "Add"
        btnAdd.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.ForeColor = Color.Black
        btnClear.Location = New Point(279, 328)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(141, 35)
        btnClear.TabIndex = 10
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnDelete
        ' 
        btnDelete.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnDelete.ForeColor = Color.Black
        btnDelete.Location = New Point(50, 410)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(141, 35)
        btnDelete.TabIndex = 11
        btnDelete.Text = "Delete"
        btnDelete.UseVisualStyleBackColor = True
        ' 
        ' btnGeneratePDF
        ' 
        btnGeneratePDF.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnGeneratePDF.ForeColor = Color.Black
        btnGeneratePDF.Location = New Point(279, 386)
        btnGeneratePDF.Name = "btnGeneratePDF"
        btnGeneratePDF.Size = New Size(141, 35)
        btnGeneratePDF.TabIndex = 12
        btnGeneratePDF.Text = "Generate PDF"
        btnGeneratePDF.UseVisualStyleBackColor = True
        ' 
        ' btnUpdate
        ' 
        btnUpdate.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnUpdate.ForeColor = Color.Black
        btnUpdate.Location = New Point(50, 369)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(141, 35)
        btnUpdate.TabIndex = 13
        btnUpdate.Text = "Update"
        btnUpdate.UseVisualStyleBackColor = True
        ' 
        ' dgvStudents
        ' 
        dgvStudents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvStudents.GridColor = SystemColors.ControlDark
        dgvStudents.Location = New Point(475, 106)
        dgvStudents.Name = "dgvStudents"
        dgvStudents.ReadOnly = True
        dgvStudents.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvStudents.Size = New Size(240, 150)
        dgvStudents.TabIndex = 14
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(598, 328)
        Label5.Name = "Label5"
        Label5.Size = New Size(35, 15)
        Label5.TabIndex = 15
        Label5.Text = "Label"
        Label5.Visible = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(810, 523)
        Controls.Add(Label5)
        Controls.Add(dgvStudents)
        Controls.Add(btnUpdate)
        Controls.Add(btnGeneratePDF)
        Controls.Add(btnDelete)
        Controls.Add(btnClear)
        Controls.Add(btnAdd)
        Controls.Add(txtEmail)
        Controls.Add(Label4)
        Controls.Add(txtCourse)
        Controls.Add(Label3)
        Controls.Add(txtAge)
        Controls.Add(Label2)
        Controls.Add(txtName)
        Controls.Add(Label1)
        Controls.Add(lblTitle)
        Name = "Form1"
        Text = "Form1"
        CType(dgvStudents, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtAge As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtCourse As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnGeneratePDF As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents dgvStudents As DataGridView
    Friend WithEvents Label5 As Label

End Class
